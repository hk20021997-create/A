# UAN / ESI document scanner (Android, offline)

Reads Aadhaar, PAN, driving licence and bank-detail photos/PDFs on the phone, shows the
details for checking, and adds a row to your UAN-ESI Excel template.

## Get the APK without installing anything (GitHub does the build)

1. Make a free account at github.com and press **New repository** (name: uanscan, Private is fine).
2. On the new repository page choose **uploading an existing file** and drag in EVERYTHING from this folder
   (the folders `app`, the files `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`, `README.md`).
3. The hidden folder `.github` may not upload by drag-and-drop. Then press **Add file > Create new file**,
   type the name `.github/workflows/build.yml` and paste the contents of that file from this folder. Commit.
4. Open the **Actions** tab. A run called "Build APK" starts by itself (about 5-8 minutes).
5. When it shows a green tick, open it and download **UANScan-APK** at the bottom. Unzip it: `app-debug.apk`.
6. Copy the APK to the phone, open it, allow "install unknown apps" when asked.

## Using the app

1. **Choose template** - pick your Excel (the app works on its own copy, your original is never touched).
2. **Batch details** - client, sub-contractor, joining date, wages etc. Set once; used for every person.
3. **Select documents** - choose all photos/PDFs of one person together.
4. Check/correct the fields (red = looks wrong; the Aadhaar number is checked with its check digit), press **Save to Excel**.
5. Repeat for the next person. At the end press **Save Excel to phone**.

## Notes

- Text in the photos is read by Google ML Kit, bundled inside the app, so no internet is needed. Needs Android 8.0 or newer.
- Handwritten text (e.g. father's date of birth, qualification) is not reliably read - type those on the check screen.
- Present and permanent address, nominee and family member 1 are all filled from the Aadhaar address / father's name; edit in Excel if different.
- New rows copy the formatting of the last filled row. SL NO continues from the last row.
