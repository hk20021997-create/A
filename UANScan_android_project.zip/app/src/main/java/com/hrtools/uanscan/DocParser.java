package com.hrtools.uanscan;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Turns the OCR text of Aadhaar / PAN / driving licence / bank documents into one Person.
 * Pure Java (no Android classes) so it can be tested on a PC.
 */
public final class DocParser {
    private DocParser() {}

    private static final class Doc {
        int rank = 4;
        Person p = new Person();
    }

    private static final String[] JUNK = {
        "GOVERNMENT", "GOVT", "INDIA", "AUTHORITY", "UNIQUE", "IDENTIFICATION", "MALE", "FEMALE",
        "DOB", "ADDRESS", "AADHAAR", "INCOME", "TAX", "DEPARTMENT", "PERMANENT", "ACCOUNT", "NUMBER",
        "CARD", "FATHER", "BIRTH", "DATE", "SIGNATURE", "LICENCE", "DRIVING", "BANK", "BRANCH",
        "VALID", "BLOOD", "GROUP", "CATEGORY", "TRANSPORT", "KERALA", "STATE", "UNION", "PHOTO"
    };

    private static final Map<String, String> BANKS = new HashMap<>();
    static {
        String[] b = {
            "SBIN", "STATE BANK OF INDIA", "IOBA", "INDIAN OVERSEAS BANK", "CNRB", "CANARA BANK",
            "FDRL", "FEDERAL BANK", "IDIB", "INDIAN BANK", "HDFC", "HDFC BANK", "ICIC", "ICICI BANK",
            "UTIB", "AXIS BANK", "KARB", "KARNATAKA BANK", "CIUB", "CITY UNION BANK",
            "UBIN", "UNION BANK OF INDIA", "BARB", "BANK OF BARODA", "PUNB", "PUNJAB NATIONAL BANK",
            "KVBL", "KARUR VYSYA BANK", "TMBL", "TAMILNAD MERCANTILE BANK", "SIBL", "SOUTH INDIAN BANK",
            "IDFB", "IDFC FIRST BANK", "BKID", "BANK OF INDIA", "CBIN", "CENTRAL BANK OF INDIA",
            "UCBA", "UCO BANK", "INDB", "INDUSIND BANK", "KKBK", "KOTAK MAHINDRA BANK", "YESB", "YES BANK",
            "IPOS", "INDIA POST PAYMENTS BANK", "PYTM", "PAYTM PAYMENTS BANK", "DLXB", "DHANLAXMI BANK",
            "CSBK", "CSB BANK", "KLGB", "KERALA GRAMIN BANK", "MAHB", "BANK OF MAHARASHTRA",
            "PSIB", "PUNJAB & SIND BANK", "AIRP", "AIRTEL PAYMENTS BANK", "ESFB", "EQUITAS SMALL FINANCE BANK",
            "AUBL", "AU SMALL FINANCE BANK", "TNSC", "TAMILNADU STATE APEX CO-OP BANK"
        };
        for (int i = 0; i < b.length; i += 2) BANKS.put(b[i], b[i + 1]);
    }

    private static final Pattern DATE = Pattern.compile("(?<!\\d)(\\d{2})\\s*[/\\-.]\\s*(\\d{2})\\s*[/\\-.]\\s*(\\d{4})(?!\\d)");
    private static final Pattern EMAIL = Pattern.compile("[A-Za-z0-9._%+\\-]+@[A-Za-z0-9.\\-]+\\.[A-Za-z]{2,}");
    private static final Pattern PAN = Pattern.compile("[A-Z]{5}[0-9]{4}[A-Z]");

    // ---------------------------------------------------------------- public API

    public static Person parseAll(List<String> texts) {
        List<Doc> docs = new ArrayList<>();
        for (String t : texts) {
            if (t != null && !t.trim().isEmpty()) docs.add(parseOne(t));
        }
        Collections.sort(docs, new Comparator<Doc>() {
            @Override public int compare(Doc a, Doc b) { return Integer.compare(a.rank, b.rank); }
        });
        Person out = new Person();
        out.relation = "";
        for (Doc d : docs) merge(out, d.p);
        if (out.name.isEmpty() && out.bankHolder.isEmpty()) out.name = consensusName(texts);
        if (out.dob.isEmpty()) out.dob = consensusDob(texts);
        finish(out);
        return out;
    }

    // ---------------------------------------------------------------- one document

    private static Doc parseOne(String text) {
        Doc d = new Doc();
        Person p = d.p;
        String[] raw = text.split("\\r?\\n");
        List<String> lines = new ArrayList<>();
        for (String s : raw) {
            String t = s.trim();
            if (!t.isEmpty()) lines.add(t);
        }
        String up = text.toUpperCase();
        String aad = findAadhaar(text);

        boolean bank = up.contains("IFSC") || up.contains("ACCOUNT NUMBER") || up.contains("A/C NO");
        boolean pan = up.contains("INCOME TAX") || up.contains("PERMANENT ACCOUNT");
        boolean dl = up.contains("DRIVING") || up.contains("LICENCE") || up.contains("LICENSE");
        boolean aadhaarWords = up.contains("AADHAAR") || up.contains("UIDAI") || up.contains("UNIQUE IDENTIFICATION");
        if (aad != null && bank && !aadhaarWords) aad = null;   // a bank sheet's 12-digit mobile can pass the check digit
        boolean aadhaar = aadhaarWords || (aad != null && !pan && !dl);

        if (aadhaar) d.rank = Math.min(d.rank, 0);
        if (pan) d.rank = Math.min(d.rank, 1);
        if (dl) d.rank = Math.min(d.rank, 2);
        if (bank) d.rank = Math.min(d.rank, 3);

        if (aad != null) p.aadhaar = aad;

        String dob = findDob(lines);
        if (!dob.isEmpty()) p.dob = dob;

        if (aadhaar) {
            if (up.matches("(?s).*\\bFEMALE\\b.*")) p.gender = "FEMALE";
            else if (up.matches("(?s).*\\bMALE\\b.*")) p.gender = "MALE";
            p.name = aadhaarName(lines);
            readAadhaarAddress(text, p);
        }
        if (pan) {
            String n = nameAfterLabel(lines, "NAME", "FATHER");
            if (p.name.isEmpty()) p.name = n;
            String f = nameAfterLabel(lines, "FATHER", null);
            if (p.father.isEmpty()) p.father = f;
        }
        if (dl) {
            Matcher m = Pattern.compile("(?im)^\\W*Name\\s*[:\\-]?\\s+(.+)$").matcher(text);
            if (m.find()) {
                String n = cleanName(m.group(1));
                if (p.name.isEmpty() && isNameLine(n)) p.name = n;
            }
            Matcher f = Pattern.compile("(?i)S\\s*/\\s*[WD]\\s*/\\s*[WD]\\s*of\\W*([A-Za-z .]+)").matcher(text);
            if (f.find()) {
                String n = cleanName(f.group(1));
                if (isNameLine(n)) p.father = n;
            }
            Matcher l = Pattern.compile("(?<!\\d)(\\d{2}/\\d{3,5}/\\d{4})(?!\\d)").matcher(text);
            if (l.find()) p.licence = l.group(1);
            else {
                Matcher l2 = Pattern.compile("\\b([A-Z]{2}\\d{2}\\s?\\d{11})\\b").matcher(up);
                if (l2.find()) p.licence = l2.group(1).replace(" ", "");
            }
            if (p.address.isEmpty()) {
                Matcher a = Pattern.compile("(?is)Address\\W{0,3}(.{5,200}?)(?<!\\d)(\\d{6})(?!\\d)").matcher(flat(text));
                if (a.find()) {
                    p.address = a.group(1).replaceAll("\\s+", " ").trim().toUpperCase();
                    p.pin = a.group(2);
                }
            }
        }
        Matcher bg = Pattern.compile("(?i)b[il1]ood\\s*gr\\w*\\W{0,4}(AB|A|B|O)\\s*([+\\-]|pos|neg)").matcher(text);
        if (bg.find()) p.blood = bg.group(1).toUpperCase() + (bg.group(2).startsWith("-") || bg.group(2).toLowerCase().startsWith("n") ? "-VE" : "+VE");
        String pn = findPan(up);
        if (pn != null) p.pan = pn;

        if (bank) {
            readBank(text, lines, p);
        }
        // contact details can be on the bank sheet or typed forms
        if (p.mobile.isEmpty()) p.mobile = findMobile(lines);
        if (p.email.isEmpty()) p.email = findEmail(lines);
        return d;
    }

    private static void merge(Person o, Person n) {
        o.name = pick(o.name, n.name); o.father = pick(o.father, n.father);
        o.relation = pick(o.relation, n.relation);
        o.dob = pick(o.dob, n.dob); o.gender = pick(o.gender, n.gender);
        o.aadhaar = pick(o.aadhaar, n.aadhaar); o.mobile = pick(o.mobile, n.mobile);
        o.pan = pick(o.pan, n.pan); o.licence = pick(o.licence, n.licence);
        o.email = pick(o.email, n.email); o.blood = pick(o.blood, n.blood);
        o.ifsc = pick(o.ifsc, n.ifsc); o.account = pick(o.account, n.account);
        o.bankHolder = pick(o.bankHolder, n.bankHolder); o.bankName = pick(o.bankName, n.bankName);
        o.branch = pick(o.branch, n.branch);
        o.address = pick(o.address, n.address); o.district = pick(o.district, n.district);
        o.state = pick(o.state, n.state); o.pin = pick(o.pin, n.pin);
    }

    private static String pick(String a, String b) { return a.isEmpty() ? b : a; }

    private static void finish(Person p) {
        p.name = p.name.toUpperCase();
        if (p.name.isEmpty()) p.name = p.bankHolder.toUpperCase();
        p.father = p.father.toUpperCase();
        if (p.relation.isEmpty()) p.relation = "FATHER";
        p.bankHolder = p.bankHolder.toUpperCase();
        p.branch = p.branch.toUpperCase();
        p.address = p.address.toUpperCase();
        p.district = p.district.toUpperCase();
        p.state = p.state.toUpperCase();
        p.ifsc = p.ifsc.toUpperCase();
        p.pan = p.pan.toUpperCase();
        if (p.pan.isEmpty()) p.pan = p.licence.toUpperCase();
        p.email = p.email.toLowerCase();
        p.aadhaar = p.aadhaar.replaceAll("\\D", "");
        p.mobile = p.mobile.replaceAll("\\D", "");
        if (p.mobile.length() == 12 && p.mobile.startsWith("91")) p.mobile = p.mobile.substring(2);
        if (p.mobile.equals(p.account)) p.mobile = "";
        if (p.bankName.isEmpty() && p.ifsc.length() >= 4) {
            String b = BANKS.get(p.ifsc.substring(0, 4));
            if (b != null) p.bankName = b;
        }
        if (p.bankHolder.isEmpty()) p.bankHolder = p.name;
    }

    // ---------------------------------------------------------------- field finders

    private static final String[] ADDR_WORDS = {"HOUSE", "ROAD", "STREET", "COLONY", "NAGAR", "TOWN", "VILLAGE", "POST", "OFFICE",
        "DISTRICT", "PIN", "CODE", "SAVINGS", "SCHEME", "STANDARD", "ACTIVE", "SINGLE", "REGISTERED", "MODE", "TYPE", "EMAIL", "MOBILE",
        "CUSTOMER", "EFFECTIVE", "AVAILABLE", "BALANCE", "PHONE", "BANKING", "PARTNER", "YOUR", "PERFECT", "SWIFT", "MICR", "NOMINATION",
        "CURRENCY", "COMMUNICATION", "UPDATED", "OPEN", "JOINT", "HOLDERS", "SERVICES", "UNIT", "PLOT", "SECTOR", "NAVI", "MUMBAI", "LOST", "FOUND", "CASE", "THIS"};

    /** Fallback: a person-name-like phrase that shows up in two or more of the documents. */
    static String consensusName(List<String> texts) {
        Map<String, Integer> count = new HashMap<>();
        Pattern pt = Pattern.compile("\\b[A-Z][A-Za-z]{2,}(?:[ \\t]+[A-Z][A-Za-z]*\\.?){1,2}");
        for (String t : texts) {
            java.util.Set<String> seen = new java.util.HashSet<>();
            Matcher m = pt.matcher(t);
            while (m.find()) {
                String c = m.group().trim().replaceAll("\\s+", " ").toUpperCase();
                if (!isNameLine(c)) continue;
                boolean bad = false;
                for (String w : ADDR_WORDS) if (c.matches("(?s).*\\b" + w + "\\b.*")) bad = true;
                if (!bad) seen.add(c);
            }
            for (String c : seen) count.merge(c, 1, Integer::sum);
        }
        String best = "";
        int bc = 1;
        for (Map.Entry<String, Integer> e : count.entrySet()) {
            if (e.getValue() > bc || (e.getValue() == bc && e.getValue() > 1 && e.getKey().length() < best.length())) {
                best = e.getKey();
                bc = e.getValue();
            }
        }
        return best;
    }

    /** Fallback: a plausible date of birth that shows up in two or more documents. */
    static String consensusDob(List<String> texts) {
        Map<String, Integer> count = new HashMap<>();
        for (String t : texts) {
            java.util.Set<String> seen = new java.util.HashSet<>();
            Matcher m = DATE.matcher(t);
            while (m.find()) {
                int day = Integer.parseInt(m.group(1)), mon = Integer.parseInt(m.group(2)), yr = Integer.parseInt(m.group(3));
                if (day < 1 || day > 31 || mon < 1 || mon > 12 || yr < 1950 || yr > 2010) continue;
                seen.add(m.group(1) + "/" + m.group(2) + "/" + m.group(3));
            }
            for (String c : seen) count.merge(c, 1, Integer::sum);
        }
        String best = "";
        int bc = 1;
        for (Map.Entry<String, Integer> e : count.entrySet()) {
            if (e.getValue() > bc) { best = e.getKey(); bc = e.getValue(); }
        }
        return best;
    }

    static String flat(String t) { return t.replaceAll("[\\r\\n]+", " "); }

    static String findAadhaar(String text) {
        Matcher m = Pattern.compile("(?<!\\d)(\\d{4})\\s?(\\d{4})\\s?(\\d{4})(?!\\d)").matcher(text);
        while (m.find()) {
            String s = m.group(1) + m.group(2) + m.group(3);
            if (Verhoeff.validAadhaar(s)) return s;
        }
        return null;
    }

    static String findPan(String up) {
        Matcher m = Pattern.compile("(?<![A-Z0-9])[A-Z0-9]{10}(?![A-Z0-9])").matcher(up);
        while (m.find()) {
            String t = m.group();
            if (PAN.matcher(t).matches()) return t;
            int letters = 0;
            for (int i = 0; i < 5; i++) if (Character.isLetter(t.charAt(i))) letters++;
            if (letters < 3) continue;
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 10; i++) {
                char c = t.charAt(i);
                boolean wantLetter = i < 5 || i == 9;
                sb.append(wantLetter ? toLetter(c) : toDigit(c));
            }
            if (PAN.matcher(sb).matches()) return sb.toString();
        }
        return null;
    }

    private static char toLetter(char c) {
        switch (c) { case '0': return 'O'; case '1': return 'I'; case '5': return 'S'; case '8': return 'B'; case '2': return 'Z'; default: return c; }
    }

    private static char toDigit(char c) {
        switch (c) { case 'O': return '0'; case 'I': case 'L': return '1'; case 'S': return '5'; case 'B': return '8'; case 'Z': return '2'; default: return c; }
    }

    static String findDob(List<String> lines) {
        for (int i = 0; i < lines.size(); i++) {
            Matcher m = DATE.matcher(lines.get(i));
            while (m.find()) {
                String ctx = lines.get(i) + " " + (i > 0 ? lines.get(i - 1) : "");
                String u = ctx.toUpperCase();
                if (!(u.contains("BIRTH") || u.contains("DOB") || u.contains("D.O.B") || u.contains("जन्म"))) continue;
                int day = Integer.parseInt(m.group(1)), mon = Integer.parseInt(m.group(2)), yr = Integer.parseInt(m.group(3));
                if (day < 1 || day > 31 || mon < 1 || mon > 12 || yr < 1940 || yr > 2015) continue;
                return m.group(1) + "/" + m.group(2) + "/" + m.group(3);
            }
        }
        return "";
    }

    static boolean isNameLine(String s) {
        if (s == null) return false;
        s = s.trim();
        if (!s.matches("[A-Za-z][A-Za-z .']{1,38}[A-Za-z.]")) return false;
        String u = s.toUpperCase();
        for (String j : JUNK) if (u.matches("(?s).*\\b" + j + "\\b.*")) return false;
        return true;
    }

    static String cleanName(String s) {
        s = s.trim().replaceAll("\\s{2,}.*$", "").replaceAll("(?i)\\s+Branch.*$", "");
        return s.replaceAll("[^A-Za-z .']", "").trim();
    }

    /** Name on the Aadhaar front: the clean text line just above the DOB line. */
    static String aadhaarName(List<String> lines) {
        for (int i = 0; i < lines.size(); i++) {
            String u = lines.get(i).toUpperCase();
            if ((u.contains("DOB") || u.contains("D.O.B") || u.contains("DATE OF BIRTH") || u.contains("YEAR OF BIRTH")) && DATE.matcher(lines.get(i)).find()) {
                for (int j = i - 1; j >= Math.max(0, i - 3); j--) {
                    String n = cleanName(lines.get(j));
                    if (isNameLine(n)) return n;
                }
            }
        }
        return "";
    }

    /** Value on the line after a label line (used for PAN: "Name" then the name). */
    static String nameAfterLabel(List<String> lines, String label, String exclude) {
        for (int i = 0; i < lines.size(); i++) {
            String u = lines.get(i).toUpperCase();
            if (!u.contains(label)) continue;
            if (exclude != null && u.contains(exclude)) continue;
            if (u.contains("ACCOUNT") || u.contains("DEPARTMENT")) continue;
            for (int j = i + 1; j <= Math.min(lines.size() - 1, i + 2); j++) {
                String n = cleanName(lines.get(j));
                if (isNameLine(n)) return n;
            }
        }
        return "";
    }

    private static void readAadhaarAddress(String text, Person p) {
        Matcher m = Pattern.compile("(?is)Address\\s*:?\\s*(.{5,300}?)(?<!\\d)(\\d{6})(?!\\d)").matcher(flat(text));
        if (!m.find()) {
            m = Pattern.compile("(?is)\\b([SDWC]\\s*/\\s*O\\b.{5,300}?)(?<!\\d)(\\d{6})(?!\\d)").matcher(flat(text));
            if (!m.find()) return;
        }
        String a = m.group(1).trim();
        String pin = m.group(2);
        Matcher so = Pattern.compile("(?i)^([SDWCH])\\s*/\\s*O\\s*:?\\s*([^,.]+)[,.]\\s*(.*)$").matcher(a);
        if (so.find()) {
            String kind = so.group(1).toUpperCase();
            String who = cleanName(so.group(2));
            if (!who.isEmpty() && !kind.equals("C")) {
                p.father = who;
                p.relation = kind.equals("W") ? "HUSBAND" : "FATHER";
            }
            a = so.group(3);
        }
        List<String> tokens = new ArrayList<>();
        for (String t : a.split(",")) {
            String s = t.replaceAll("\\s+", " ").trim();
            if (!s.isEmpty() && !s.equals(".")) tokens.add(s.toUpperCase());
        }
        if (tokens.size() < 2) return;
        String state = tokens.remove(tokens.size() - 1).replace("TAMIL NADU", "TAMILNADU");
        String district = tokens.isEmpty() ? "" : tokens.get(tokens.size() - 1);
        p.state = state;
        p.district = district;
        p.pin = pin;
        StringBuilder sb = new StringBuilder();
        for (String t : tokens) sb.append(t).append(", ");
        sb.append(state).append(". ").append(pin);
        p.address = sb.toString();
    }

    private static void readBank(String text, List<String> lines, Person p) {
        String up = text.toUpperCase();
        // IFSC: 4 letters, a zero, 6 letters/digits
        Matcher m = Pattern.compile("(?<![A-Z0-9])([A-Z0-9]{4})([0O])([A-Z0-9]{6})(?![A-Z0-9])").matcher(up);
        while (m.find()) {
            String first = m.group(1).replace('0', 'O').replace('1', 'I');
            if (!first.matches("[A-Z]{4}")) continue;
            boolean known = BANKS.containsKey(first);
            String last = m.group(3);
            if (known || up.contains("IFSC")) {
                p.ifsc = first + "0" + last;
                break;
            }
        }
        // Account number
        String ex = excludeDigits(lines);
        for (int i = 0; i < lines.size() && p.account.isEmpty(); i++) {
            String u = lines.get(i).toUpperCase();
            if (u.contains("ACCOUNT NUMBER") || u.contains("ACCOUNT NO") || u.contains("A/C NO")) {
                for (int j = i; j <= Math.min(lines.size() - 1, i + 2); j++) {
                    Matcher d = Pattern.compile("(?<!\\d)(\\d{9,18})(?!\\d)").matcher(lines.get(j));
                    while (d.find()) {
                        if (!ex.contains("|" + d.group(1) + "|")) { p.account = d.group(1); break; }
                    }
                    if (!p.account.isEmpty()) break;
                }
            }
        }
        if (p.account.isEmpty()) {
            String best = "";
            Matcher d = Pattern.compile("(?<!\\d)(\\d{11,18})(?!\\d)").matcher(text);
            while (d.find()) {
                String s = d.group(1);
                if (ex.contains("|" + s + "|")) continue;
                if (s.length() > best.length()) best = s;
            }
            p.account = best;
        }
        // holder name and branch
        Matcher h = Pattern.compile("(?im)^\\W*Name\\s*[:\\-]\\s*(.+)$").matcher(text);
        if (h.find()) {
            String n = cleanName(h.group(1));
            if (isNameLine(n)) p.bankHolder = n;
        }
        if (p.bankHolder.isEmpty()) {
            Matcher h2 = Pattern.compile("(?i)\\bNa\\w{1,2}\\W{1,3}([A-Za-z][A-Za-z .]{2,40}?)\\s+Branch").matcher(text);
            if (h2.find()) {
                String n = cleanName(h2.group(1));
                if (isNameLine(n)) p.bankHolder = n;
            }
        }
        Matcher br = Pattern.compile("(?i)Branch\\s*Name\\s*[:\\-]?\\s*([A-Za-z][A-Za-z .&\\-]{1,40})").matcher(text);
        if (br.find()) p.branch = br.group(1).replaceAll("\\s+", " ").trim();
        // bank name from known text
        for (String b : new String[]{"FEDERAL BANK", "STATE BANK OF INDIA", "CANARA BANK", "INDIAN OVERSEAS BANK", "INDIAN BANK", "HDFC BANK", "ICICI BANK", "AXIS BANK", "UNION BANK OF INDIA", "BANK OF BARODA", "KARNATAKA BANK", "CITY UNION BANK"}) {
            if (up.contains(b)) { p.bankName = b; break; }
        }
    }

    /** Digit strings that are NOT the account number: Aadhaar, mobile, customer id, MICR. */
    private static String excludeDigits(List<String> lines) {
        StringBuilder sb = new StringBuilder("|");
        for (int i = 0; i < lines.size(); i++) {
            String u = lines.get(i).toUpperCase();
            if (u.contains("CUSTOMER") || u.contains("MICR") || u.contains("MOBILE") || u.contains("SOL ID") || u.contains("REGD")) {
                Matcher d = Pattern.compile("(?<!\\d)\\d{6,18}(?!\\d)").matcher(lines.get(i));
                while (d.find()) sb.append(d.group()).append("|");
            }
        }
        return sb.toString();
    }

    static String findMobile(List<String> lines) {
        Pattern pt = Pattern.compile("(?<!\\d)(?:\\+?91[\\s\\-]?)?([6-9]\\d{9})(?!\\d)");
        for (int i = 0; i < lines.size(); i++) {
            String u = lines.get(i).toUpperCase();
            if (u.contains("MOBILE") || u.contains("MOB.") || u.contains("PHONE")) {
                Matcher m = pt.matcher(lines.get(i));
                if (m.find()) return m.group(1);
            }
        }
        return "";
    }

    static String findEmail(List<String> lines) {
        String fallback = "";
        for (String l : lines) {
            Matcher m = EMAIL.matcher(l);
            while (m.find()) {
                String e = m.group().toLowerCase();
                if (e.contains("federalbank") || e.contains("uidai") || e.endsWith(".gov.in") || e.startsWith("contact@") || e.startsWith("help@")) continue;
                if (l.toUpperCase().contains("EMAIL")) return e;
                if (fallback.isEmpty()) fallback = e;
            }
        }
        return fallback;
    }
}
