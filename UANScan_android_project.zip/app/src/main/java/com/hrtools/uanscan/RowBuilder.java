package com.hrtools.uanscan;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.LinkedHashMap;
import java.util.Map;

/** Maps a Person + batch defaults to template columns (A..CG). Values are String, Long or Integer. */
public final class RowBuilder {
    private RowBuilder() {}

    private static Object date(String s) {
        LocalDate d = Validate.parseDate(s);
        if (d == null) return s == null ? "" : s;
        return Long.valueOf(ChronoUnit.DAYS.between(LocalDate.of(1899, 12, 30), d));
    }

    private static Object num(String s) {
        if (s == null) return "";
        String t = s.trim();
        if (t.matches("\\d{1,9}")) return Integer.valueOf(Integer.parseInt(t));
        if (t.matches("\\d{10,15}")) return Long.valueOf(Long.parseLong(t));
        return t;
    }

    public static Map<String, Object> build(Person p, Defaults d) {
        Map<String, Object> r = new LinkedHashMap<>();
        r.put("K", p.name);
        r.put("L", p.father);
        r.put("M", date(p.dob));
        r.put("N", date(d.doj));
        r.put("Q", p.gender);
        r.put("R", d.marital);
        r.put("S", d.client);
        r.put("T", d.subContractor);
        r.put("U", p.aadhaar);
        r.put("V", num(p.mobile));
        r.put("W", p.pan);
        r.put("X", p.email);
        r.put("Y", p.blood);
        r.put("Z", p.qualification);
        r.put("AA", num(d.esicWages));
        r.put("AB", num(d.epfWages));
        r.put("AC", p.ifsc);
        r.put("AD", p.account);
        r.put("AE", p.bankHolder);
        r.put("AF", p.bankName);
        r.put("AG", p.branch);
        r.put("AH", d.remitLoc);
        r.put("AI", d.dispensary);
        // present address
        r.put("AJ", p.address); r.put("AK", p.district); r.put("AL", p.state); r.put("AM", num(p.pin));
        // permanent address (same as present; edit in Excel if different)
        r.put("AN", p.address); r.put("AO", p.district); r.put("AP", p.state); r.put("AQ", num(p.pin));
        // nominee = father / husband
        r.put("AR", p.father); r.put("AS", p.relation);
        r.put("AT", p.address); r.put("AU", p.district); r.put("AV", p.state); r.put("AW", num(p.pin));
        // family member 1 = same person
        r.put("AX", p.father); r.put("AY", date(p.fatherDob)); r.put("AZ", p.relation);
        r.put("BA", p.father.isEmpty() ? "" : "YES");
        r.put("BB", p.district); r.put("BC", p.state);
        return r;
    }
}
