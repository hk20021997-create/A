package com.hrtools.uanscan

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

/** Reads text from photos and PDFs on the phone itself (no internet). */
object OcrEngine {
    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    private suspend fun recognize(image: InputImage): String = suspendCoroutine { cont ->
        recognizer.process(image)
            .addOnSuccessListener { cont.resume(it.text) }
            .addOnFailureListener { cont.resume("") }
    }

    /** Returns one text per photo, or one text per PDF page. */
    suspend fun read(ctx: Context, uri: Uri): List<String> {
        val mime = ctx.contentResolver.getType(uri) ?: ""
        val isPdf = mime.contains("pdf") || uri.toString().lowercase().endsWith(".pdf")
        return if (isPdf) readPdf(ctx, uri) else readImage(ctx, uri)
    }

    private suspend fun readImage(ctx: Context, uri: Uri): List<String> {
        return try {
            // fromFilePath also applies the photo's rotation (WhatsApp photos are often sideways)
            listOf(recognize(InputImage.fromFilePath(ctx, uri)))
        } catch (e: Exception) {
            emptyList()
        }
    }

    private suspend fun readPdf(ctx: Context, uri: Uri): List<String> {
        val out = mutableListOf<String>()
        try {
            val pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: return out
            val renderer = PdfRenderer(pfd)
            try {
                val pages = minOf(renderer.pageCount, 6)
                for (i in 0 until pages) {
                    val page = renderer.openPage(i)
                    try {
                        val scale = 2.5f
                        val w = (page.width * scale).toInt().coerceAtLeast(1)
                        val h = (page.height * scale).toInt().coerceAtLeast(1)
                        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        bmp.eraseColor(Color.WHITE)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        out.add(recognize(InputImage.fromBitmap(bmp, 0)))
                        bmp.recycle()
                    } finally {
                        page.close()
                    }
                }
            } finally {
                renderer.close()
                pfd.close()
            }
        } catch (e: Exception) {
            // unreadable PDF: return what we have
        }
        return out
    }
}
