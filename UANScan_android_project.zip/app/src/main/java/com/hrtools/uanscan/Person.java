package com.hrtools.uanscan;

import java.util.LinkedHashMap;
import java.util.Map;

/** One employee's data, as read from the documents and corrected on the review screen. */
public class Person {
    public String name = "", father = "", relation = "FATHER", dob = "", gender = "";
    public String aadhaar = "", mobile = "", pan = "", licence = "", email = "", blood = "";
    public String qualification = "", fatherDob = "";
    public String ifsc = "", account = "", bankHolder = "", bankName = "", branch = "";
    public String address = "", district = "", state = "", pin = "";

    /** Keys in the order they are shown on the review screen. */
    public static final String[][] FIELDS = {
        {"name", "Name (as per Aadhaar)"},
        {"father", "Father / Husband name"},
        {"relation", "Relationship (FATHER / HUSBAND ...)"},
        {"fatherDob", "Father / nominee date of birth (dd/mm/yyyy)"},
        {"dob", "Date of birth (dd/mm/yyyy)"},
        {"gender", "Gender (MALE / FEMALE)"},
        {"aadhaar", "Aadhaar number"},
        {"mobile", "Mobile number"},
        {"pan", "PAN / Licence / Passport number"},
        {"email", "Email"},
        {"blood", "Blood group"},
        {"qualification", "Qualification"},
        {"ifsc", "IFSC code"},
        {"account", "Bank account number"},
        {"bankHolder", "Name as per bank records"},
        {"bankName", "Bank name"},
        {"branch", "Branch"},
        {"address", "Address"},
        {"district", "District"},
        {"state", "State"},
        {"pin", "PIN code"},
    };

    public Map<String, String> toMap() {
        LinkedHashMap<String, String> m = new LinkedHashMap<>();
        m.put("name", name); m.put("father", father); m.put("relation", relation);
        m.put("fatherDob", fatherDob); m.put("dob", dob); m.put("gender", gender);
        m.put("aadhaar", aadhaar); m.put("mobile", mobile);
        m.put("pan", pan.isEmpty() ? licence : pan);
        m.put("email", email); m.put("blood", blood); m.put("qualification", qualification);
        m.put("ifsc", ifsc); m.put("account", account); m.put("bankHolder", bankHolder);
        m.put("bankName", bankName); m.put("branch", branch); m.put("address", address);
        m.put("district", district); m.put("state", state); m.put("pin", pin);
        return m;
    }

    private static String g(Map<String, String> m, String k) {
        String v = m.get(k);
        return v == null ? "" : v.trim();
    }

    public static Person fromMap(Map<String, String> m) {
        Person p = new Person();
        p.name = g(m, "name"); p.father = g(m, "father"); p.relation = g(m, "relation");
        p.fatherDob = g(m, "fatherDob"); p.dob = g(m, "dob"); p.gender = g(m, "gender");
        p.aadhaar = g(m, "aadhaar"); p.mobile = g(m, "mobile"); p.pan = g(m, "pan");
        p.email = g(m, "email"); p.blood = g(m, "blood"); p.qualification = g(m, "qualification");
        p.ifsc = g(m, "ifsc"); p.account = g(m, "account"); p.bankHolder = g(m, "bankHolder");
        p.bankName = g(m, "bankName"); p.branch = g(m, "branch"); p.address = g(m, "address");
        p.district = g(m, "district"); p.state = g(m, "state"); p.pin = g(m, "pin");
        return p;
    }
}
