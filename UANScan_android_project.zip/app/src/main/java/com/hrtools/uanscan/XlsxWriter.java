package com.hrtools.uanscan;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * Adds one row to the first sheet of an .xlsx file by editing the sheet XML directly.
 * Everything else in the file (merged headers, widths, colours, hidden columns) stays exactly as it was,
 * and the new row copies the cell styles of the last filled row.
 */
public final class XlsxWriter {
    private XlsxWriter() {}

    public static final class Info {
        public int lastRow;   // last row that has an employee name
        public int serial;    // SL NO of that row (or count)
        public String sheetName = "";
    }

    private static final Pattern ROW = Pattern.compile("<row\\b[^>]*?(?:/>|>.*?</row>)", Pattern.DOTALL);
    private static final Pattern ROW_NUM = Pattern.compile("^<row\\b[^>]*?\\br=\"(\\d+)\"");
    private static final Pattern CELL = Pattern.compile("<c\\b[^>]*?(?:/>|>.*?</c>)", Pattern.DOTALL);

    private static Map<String, byte[]> readZip(File f) throws IOException {
        Map<String, byte[]> m = new LinkedHashMap<>();
        try (ZipInputStream z = new ZipInputStream(new FileInputStream(f))) {
            ZipEntry e;
            byte[] buf = new byte[8192];
            while ((e = z.getNextEntry()) != null) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                int n;
                while ((n = z.read(buf)) > 0) bo.write(buf, 0, n);
                m.put(e.getName(), bo.toByteArray());
            }
        }
        return m;
    }

    private static String attr(String tag, String name) {
        Matcher m = Pattern.compile("\\b" + name + "=\"([^\"]*)\"").matcher(tag);
        return m.find() ? m.group(1) : null;
    }

    private static String sheetPath(Map<String, byte[]> z) throws IOException {
        byte[] wb = z.get("xl/workbook.xml");
        byte[] rel = z.get("xl/_rels/workbook.xml.rels");
        if (wb == null || rel == null) throw new IOException("Not a valid Excel (.xlsx) file");
        String wbs = new String(wb, StandardCharsets.UTF_8);
        Matcher sm = Pattern.compile("<sheet\\b[^>]*>").matcher(wbs);
        if (!sm.find()) throw new IOException("No sheet found in the workbook");
        String rid = attr(sm.group(), "r:id");
        String rels = new String(rel, StandardCharsets.UTF_8);
        Matcher rm = Pattern.compile("<Relationship\\b[^>]*>").matcher(rels);
        while (rm.find()) {
            String tag = rm.group();
            if (rid != null && rid.equals(attr(tag, "Id"))) {
                String t = attr(tag, "Target");
                if (t == null) break;
                return t.startsWith("/") ? t.substring(1) : "xl/" + t;
            }
        }
        throw new IOException("Could not locate the first sheet");
    }

    private static String sheetName(Map<String, byte[]> z) {
        String wbs = new String(z.get("xl/workbook.xml"), StandardCharsets.UTF_8);
        Matcher sm = Pattern.compile("<sheet\\b[^>]*>").matcher(wbs);
        if (sm.find()) {
            String n = attr(sm.group(), "name");
            if (n != null) return n;
        }
        return "";
    }

    private static boolean hasValue(String cellXml) {
        return cellXml.contains("<v>") || cellXml.contains("<is>") || cellXml.contains("<f");
    }

    private static String colOf(String cellTag) {
        String r = attr(cellTag, "r");
        if (r == null) return "";
        return r.replaceAll("\\d", "");
    }

    private static String esc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    /** Finds the last filled employee row (column K has a value, rows 3 and below). */
    public static Info inspect(File xlsx) throws IOException {
        Map<String, byte[]> z = readZip(xlsx);
        String path = sheetPath(z);
        String xml = new String(z.get(path), StandardCharsets.UTF_8);
        Info info = analyse(xml);
        info.sheetName = sheetName(z);
        return info;
    }

    private static Info analyse(String xml) {
        Info info = new Info();
        Matcher rm = ROW.matcher(xml);
        while (rm.find()) {
            String row = rm.group();
            Matcher nm = ROW_NUM.matcher(row);
            if (!nm.find()) continue;
            int n = Integer.parseInt(nm.group(1));
            if (n < 3) continue;
            Matcher cm = CELL.matcher(row);
            boolean hasName = false;
            String aCell = "";
            while (cm.find()) {
                String c = cm.group();
                String col = colOf(c);
                if ((col.equals("K") || col.equals("U") || col.equals("AD")) && hasValue(c)) hasName = true;
                if (col.equals("A")) aCell = c;
            }
            if (hasName && n > info.lastRow) {
                info.lastRow = n;
                Matcher v = Pattern.compile("<v>([^<]*)</v>").matcher(aCell);
                int s = info.serial + 1;
                if (v.find() && !aCell.contains("t=\"s\"")) {
                    try { s = (int) Double.parseDouble(v.group(1)); } catch (NumberFormatException ignored) { }
                }
                info.serial = s;
            }
        }
        return info;
    }

    private static int colIndex(String col) {
        int n = 0;
        for (char c : col.toCharArray()) n = n * 26 + (c - 'A' + 1);
        return n;
    }

    /**
     * Copies {@code in} to {@code out} with one new employee row added after the last filled row.
     * {@code values} maps column letters to String / Number / Date-serial values. Column A (SL NO) is filled automatically.
     * @return the row number that was written
     */
    public static int appendRow(File in, File out, Map<String, Object> values) throws IOException {
        Map<String, byte[]> z = readZip(in);
        String path = sheetPath(z);
        String xml = new String(z.get(path), StandardCharsets.UTF_8);
        Info info = analyse(xml);
        if (info.lastRow == 0) throw new IOException("Could not find an example data row in the template (column K, row 3 or below)");
        int newRow = info.lastRow + 1;

        // style source = last filled row
        String srcRow = null;
        Matcher rm = ROW.matcher(xml);
        while (rm.find()) {
            Matcher nm = ROW_NUM.matcher(rm.group());
            if (nm.find() && Integer.parseInt(nm.group(1)) == info.lastRow) { srcRow = rm.group(); break; }
        }
        if (srcRow == null) throw new IOException("Example row missing");
        Matcher open = Pattern.compile("^<row\\b[^>]*?>").matcher(srcRow);
        open.find();
        String openTag = open.group();
        if (openTag.endsWith("/>")) openTag = openTag.substring(0, openTag.length() - 2) + ">";
        openTag = openTag.replaceFirst("\\br=\"\\d+\"", "r=\"" + newRow + "\"");

        Map<String, Object> all = new LinkedHashMap<>(values);
        all.put("A", Integer.valueOf(info.serial + 1));

        StringBuilder row = new StringBuilder(openTag);
        Matcher cm = CELL.matcher(srcRow);
        java.util.Set<String> done = new java.util.HashSet<>();
        while (cm.find()) {
            String c = cm.group();
            String col = colOf(c);
            if (col.isEmpty()) continue;
            String s = attr(c.substring(0, c.indexOf('>') + 1), "s");
            row.append(cell(col, newRow, s, all.get(col)));
            done.add(col);
        }
        // columns with values that the example row had no cell for
        for (Map.Entry<String, Object> e : all.entrySet()) {
            if (!done.contains(e.getKey())) row.append(cell(e.getKey(), newRow, null, e.getValue()));
        }
        row.append("</row>");

        // replace an existing empty row with this number, or insert in order
        String newXml = null;
        Matcher rm2 = ROW.matcher(xml);
        while (rm2.find()) {
            Matcher nm = ROW_NUM.matcher(rm2.group());
            if (!nm.find()) continue;
            int n = Integer.parseInt(nm.group(1));
            if (n == newRow) {
                newXml = xml.substring(0, rm2.start()) + row + xml.substring(rm2.end());
                break;
            }
            if (n > newRow) {
                newXml = xml.substring(0, rm2.start()) + row + xml.substring(rm2.start());
                break;
            }
        }
        if (newXml == null) {
            int i = xml.indexOf("</sheetData>");
            if (i < 0) throw new IOException("Sheet has no data section");
            newXml = xml.substring(0, i) + row + xml.substring(i);
        }
        // widen the used-range marker
        Matcher dm = Pattern.compile("<dimension ref=\"([A-Z]+)(\\d+):([A-Z]+)(\\d+)\"/>").matcher(newXml);
        if (dm.find()) {
            int oldLast = Integer.parseInt(dm.group(4));
            if (newRow > oldLast) {
                newXml = newXml.substring(0, dm.start()) + "<dimension ref=\"" + dm.group(1) + dm.group(2) + ":" + dm.group(3) + newRow + "\"/>" + newXml.substring(dm.end());
            }
        }
        z.put(path, newXml.getBytes(StandardCharsets.UTF_8));

        File tmp = new File(out.getPath() + ".tmp");
        try (ZipOutputStream zo = new ZipOutputStream(new FileOutputStream(tmp))) {
            for (Map.Entry<String, byte[]> e : z.entrySet()) {
                zo.putNextEntry(new ZipEntry(e.getKey()));
                zo.write(e.getValue());
                zo.closeEntry();
            }
        }
        if (out.exists() && !out.delete()) throw new IOException("Cannot replace output file");
        if (!tmp.renameTo(out)) throw new IOException("Cannot write output file");
        return newRow;
    }

    private static String cell(String col, int row, String style, Object v) {
        String ref = col + row;
        String s = style == null ? "" : " s=\"" + style + "\"";
        if (v == null || (v instanceof String && ((String) v).isEmpty())) {
            return "<c r=\"" + ref + "\"" + s + "/>";
        }
        if (v instanceof Number) {
            return "<c r=\"" + ref + "\"" + s + "><v>" + v + "</v></c>";
        }
        return "<c r=\"" + ref + "\"" + s + " t=\"inlineStr\"><is><t xml:space=\"preserve\">" + esc(v.toString()) + "</t></is></c>";
    }
}
