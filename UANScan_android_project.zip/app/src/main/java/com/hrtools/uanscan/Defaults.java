package com.hrtools.uanscan;

/** Values that are the same for every person in a batch (not printed on the documents). */
public class Defaults {
    public String client = "AL UNIT-1 HOSUR";
    public String subContractor = "TVS VEHICLE MOBILITY SOLUTION PRIVATE LIMITED";
    public String doj = "30/09/2026";
    public String esicWages = "19000";
    public String epfWages = "15000";
    public String remitLoc = "HOSUR";
    public String dispensary = "SIPCOT-1 HOSUR";
    public String marital = "UNMARRIED";

    public static final String[][] FIELDS = {
        {"client", "Client"},
        {"subContractor", "Sub-contractor name"},
        {"doj", "Date of joining (dd/mm/yyyy)"},
        {"esicWages", "ESIC gross wages"},
        {"epfWages", "EPF wages"},
        {"remitLoc", "ESI remit location"},
        {"dispensary", "Dispensary"},
        {"marital", "Marital status (UNMARRIED / MARRIED)"},
    };
}
