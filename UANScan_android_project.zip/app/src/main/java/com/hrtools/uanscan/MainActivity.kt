package com.hrtools.uanscan

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    App(applicationContext)
                }
            }
        }
    }
}

private class Outcome(val ok: Boolean, val text: String)

private fun displayName(ctx: Context, uri: Uri): String {
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (i >= 0 && c.moveToFirst()) return c.getString(i) ?: "template.xlsx"
    }
    return "template.xlsx"
}

private fun defaultsToMap(d: Defaults): Map<String, String> = mapOf(
    "client" to d.client,
    "subContractor" to d.subContractor,
    "doj" to d.doj,
    "esicWages" to d.esicWages,
    "epfWages" to d.epfWages,
    "remitLoc" to d.remitLoc,
    "dispensary" to d.dispensary,
    "marital" to d.marital
)

private fun mapToDefaults(m: Map<String, String>): Defaults {
    val d = Defaults()
    d.client = (m["client"] ?: "").trim()
    d.subContractor = (m["subContractor"] ?: "").trim()
    d.doj = (m["doj"] ?: "").trim()
    d.esicWages = (m["esicWages"] ?: "").trim()
    d.epfWages = (m["epfWages"] ?: "").trim()
    d.remitLoc = (m["remitLoc"] ?: "").trim()
    d.dispensary = (m["dispensary"] ?: "").trim()
    d.marital = (m["marital"] ?: "").trim()
    return d
}

@Composable
fun App(ctx: Context) {
    val store = remember { Store(ctx) }
    val scope = rememberCoroutineScope()
    var defaults by remember { mutableStateOf(store.loadDefaults()) }
    var templateName by remember { mutableStateOf(store.templateName) }
    var rows by remember { mutableIntStateOf(store.rowsAdded) }
    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var review by remember { mutableStateOf<Person?>(null) }
    var reviewKey by remember { mutableIntStateOf(0) }
    var showDefaults by remember { mutableStateOf(false) }

    val pickTemplate = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                message = "Opening template..."
                val res = withContext(Dispatchers.IO) {
                    try {
                        val tmp = java.io.File(ctx.filesDir, "incoming.xlsx")
                        ctx.contentResolver.openInputStream(uri)!!.use { ins ->
                            tmp.outputStream().use { ins.copyTo(it) }
                        }
                        val info = XlsxWriter.inspect(tmp)
                        tmp.copyTo(store.working, overwrite = true)
                        tmp.delete()
                        store.templateName = displayName(ctx, uri)
                        store.rowsAdded = 0
                        Outcome(true, "Template ready. Last filled row: ${info.lastRow}. New people go below it.")
                    } catch (e: Exception) {
                        Outcome(false, "Could not use this file: ${e.message ?: "unreadable"}")
                    }
                }
                if (res.ok) {
                    templateName = store.templateName
                    rows = 0
                }
                message = res.text
                busy = false
            }
        }
    }

    val pickScans = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            scope.launch {
                busy = true
                message = "Reading ${uris.size} file(s) on the phone..."
                val person = withContext(Dispatchers.Default) {
                    val texts = mutableListOf<String>()
                    for (u in uris) texts.addAll(OcrEngine.read(ctx, u))
                    DocParser.parseAll(texts)
                }
                review = person
                reviewKey += 1
                message = ""
                busy = false
            }
        }
    }

    val export = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val res = withContext(Dispatchers.IO) {
                    try {
                        ctx.contentResolver.openOutputStream(uri)!!.use { os ->
                            store.working.inputStream().use { it.copyTo(os) }
                        }
                        Outcome(true, "Excel saved. Open it from the place you chose.")
                    } catch (e: Exception) {
                        Outcome(false, "Could not save: ${e.message ?: "error"}")
                    }
                }
                message = res.text
            }
        }
    }

    val dmap = remember { mutableStateMapOf<String, String>().apply { putAll(defaultsToMap(defaults)) } }

    val current = review
    if (current != null) {
        ReviewScreen(
            key = reviewKey,
            person = current,
            onSave = { p ->
                scope.launch {
                    busy = true
                    val res = withContext(Dispatchers.IO) {
                        try {
                            val row = XlsxWriter.appendRow(store.working, store.working, RowBuilder.build(p, defaults))
                            store.rowsAdded = store.rowsAdded + 1
                            Outcome(true, "Added to Excel row $row.")
                        } catch (e: Exception) {
                            Outcome(false, "Could not save the row: ${e.message ?: "error"}")
                        }
                    }
                    message = res.text
                    if (res.ok) {
                        rows = store.rowsAdded
                        review = null
                    }
                    busy = false
                }
            },
            onCancel = { review = null },
            message = message,
            busy = busy
        )
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("UAN / ESI document scanner", style = MaterialTheme.typography.headlineSmall)
        Text("Works fully offline. Photos and PDFs are read on this phone.")
        if (busy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("1. Excel template", style = MaterialTheme.typography.titleMedium)
                Text(if (templateName.isEmpty()) "No template chosen yet." else "$templateName  -  $rows row(s) added by this app")
                Button(onClick = { pickTemplate.launch(arrayOf("*/*")) }) {
                    Text(if (templateName.isEmpty()) "Choose template (.xlsx)" else "Choose a different template")
                }
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("2. Batch details (same for everyone)", style = MaterialTheme.typography.titleMedium)
                if (!showDefaults) {
                    Text("Client: ${defaults.client}\nSub-contractor: ${defaults.subContractor}\nJoining: ${defaults.doj}   ESIC wages: ${defaults.esicWages}   EPF wages: ${defaults.epfWages}")
                    OutlinedButton(onClick = {
                        dmap.clear()
                        dmap.putAll(defaultsToMap(defaults))
                        showDefaults = true
                    }) { Text("Edit") }
                } else {
                    for (f in Defaults.FIELDS) {
                        val k = f[0]
                        OutlinedTextField(
                            value = dmap[k] ?: "",
                            onValueChange = { dmap[k] = it },
                            label = { Text(f[1]) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            val d = mapToDefaults(dmap)
                            store.saveDefaults(d)
                            defaults = d
                            showDefaults = false
                        }) { Text("Save") }
                        OutlinedButton(onClick = { showDefaults = false }) { Text("Cancel") }
                    }
                }
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("3. Add a person", style = MaterialTheme.typography.titleMedium)
                Text("Pick all photos / PDFs of ONE person together (Aadhaar, PAN, licence, bank details). You can correct everything before it is saved.")
                Button(
                    enabled = templateName.isNotEmpty() && !busy,
                    onClick = { pickScans.launch(arrayOf("image/*", "application/pdf")) }
                ) { Text("Select documents") }
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("4. Save the finished Excel", style = MaterialTheme.typography.titleMedium)
                Button(
                    enabled = templateName.isNotEmpty() && !busy,
                    onClick = { export.launch("UAN_ESI_filled.xlsx") }
                ) { Text("Save Excel to phone") }
            }
        }

        if (message.isNotEmpty()) Text(message, color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
fun ReviewScreen(
    key: Int,
    person: Person,
    onSave: (Person) -> Unit,
    onCancel: () -> Unit,
    message: String,
    busy: Boolean
) {
    val fields = remember(key) { mutableStateMapOf<String, String>().apply { putAll(person.toMap()) } }
    var warnings = 0
    for (f in Person.FIELDS) {
        if (Validate.problem(f[0], fields[f[0]] ?: "") != null) warnings += 1
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text("Check the details", style = MaterialTheme.typography.headlineSmall)
        Text(
            if (warnings == 0) "Everything looks fine. Compare with the documents once, then save."
            else "$warnings field(s) need attention (marked in red). Handwritten text is not read - type it in."
        )
        if (busy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())

        for (f in Person.FIELDS) {
            val key2 = f[0]
            val value = fields[key2] ?: ""
            val problem = Validate.problem(key2, value)
            OutlinedTextField(
                value = value,
                onValueChange = { fields[key2] = it },
                label = { Text(f[1]) },
                isError = problem != null,
                supportingText = if (problem != null) {
                    { Text(problem) }
                } else null,
                singleLine = key2 != "address",
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 2.dp)
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
            Button(enabled = !busy, onClick = { onSave(Person.fromMap(fields)) }) { Text("Save to Excel") }
            OutlinedButton(enabled = !busy, onClick = onCancel) { Text("Discard") }
        }
        if (message.isNotEmpty()) Text(message, color = MaterialTheme.colorScheme.error)
    }
}
