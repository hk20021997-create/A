package com.hrtools.uanscan;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;

/** Gives a short warning for a field that looks wrong, or null when it looks fine. */
public final class Validate {
    private Validate() {}

    public static LocalDate parseDate(String s) {
        if (s == null) return null;
        String[] p = s.trim().split("[/\\-.]");
        if (p.length != 3) return null;
        try {
            return LocalDate.of(Integer.parseInt(p[2].trim()), Integer.parseInt(p[1].trim()), Integer.parseInt(p[0].trim()));
        } catch (NumberFormatException | DateTimeParseException e) {
            return null;
        }
    }

    public static String problem(String key, String value) {
        String v = value == null ? "" : value.trim();
        switch (key) {
            case "name": case "dob": case "aadhaar": case "mobile": case "ifsc": case "account":
                if (v.isEmpty()) return "Required - please fill in";
                break;
            default:
                if (v.isEmpty()) return null;
        }
        switch (key) {
            case "aadhaar":
                if (!v.matches("\\d{12}")) return "Must be 12 digits";
                if (!Verhoeff.validAadhaar(v)) return "Check digit fails - a digit was probably misread";
                return null;
            case "mobile":
                return v.matches("[6-9]\\d{9}") ? null : "Must be 10 digits";
            case "dob": case "fatherDob":
                return parseDate(v) == null ? "Use dd/mm/yyyy" : null;
            case "ifsc":
                return v.matches("[A-Z]{4}0[A-Z0-9]{6}") ? null : "IFSC looks wrong";
            case "pan":
                return (v.matches("[A-Z]{5}\\d{4}[A-Z]") || v.length() >= 6) ? null : "Looks wrong";
            case "pin":
                return v.matches("\\d{6}") ? null : "Must be 6 digits";
            case "email":
                return v.matches("[^@\\s]+@[^@\\s]+\\.[A-Za-z]{2,}") ? null : "Email looks wrong";
            case "account":
                return v.matches("\\d{8,18}") ? null : "Account number looks wrong";
            default:
                return null;
        }
    }
}
