package com.hrtools.uanscan

import android.content.Context
import java.io.File

/** Small on-phone storage: batch defaults, the working copy of the template, and a row counter. */
class Store(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("uanscan", Context.MODE_PRIVATE)

    val working: File get() = File(ctx.filesDir, "working.xlsx")

    var templateName: String
        get() = prefs.getString("templateName", "") ?: ""
        set(v) { prefs.edit().putString("templateName", v).apply() }

    var rowsAdded: Int
        get() = prefs.getInt("rowsAdded", 0)
        set(v) { prefs.edit().putInt("rowsAdded", v).apply() }

    fun loadDefaults(): Defaults {
        val d = Defaults()
        d.client = prefs.getString("client", d.client) ?: d.client
        d.subContractor = prefs.getString("subContractor", d.subContractor) ?: d.subContractor
        d.doj = prefs.getString("doj", d.doj) ?: d.doj
        d.esicWages = prefs.getString("esicWages", d.esicWages) ?: d.esicWages
        d.epfWages = prefs.getString("epfWages", d.epfWages) ?: d.epfWages
        d.remitLoc = prefs.getString("remitLoc", d.remitLoc) ?: d.remitLoc
        d.dispensary = prefs.getString("dispensary", d.dispensary) ?: d.dispensary
        d.marital = prefs.getString("marital", d.marital) ?: d.marital
        return d
    }

    fun saveDefaults(d: Defaults) {
        prefs.edit()
            .putString("client", d.client)
            .putString("subContractor", d.subContractor)
            .putString("doj", d.doj)
            .putString("esicWages", d.esicWages)
            .putString("epfWages", d.epfWages)
            .putString("remitLoc", d.remitLoc)
            .putString("dispensary", d.dispensary)
            .putString("marital", d.marital)
            .apply()
    }
}
